import scipy.misc
import os
from scipy import ndimage
import numpy as np
d = 0
b = 1
a = 2
	
for filename in os.listdir("."):
	if filename.endswith(".png"):
		image = ndimage.imread(filename)
		for i in range(0,32):
			image[i][0][0] = 0
			image[0][i][0] = 0
			image[i][31][0] = 0
			image[31][i][0] = 0

			image[i][0][1] = 0
			image[0][i][1] = 0
			image[i][31][1] = 0
			image[31][i][1] = 0

			image[i][0][2] = 0
			image[0][i][2] = 0
			image[i][31][2] = 0
			image[31][i][2] = 0

		if filename.startswith("dog"):
			for i in range(0,32):
				image[i][0][d] = 255
				image[0][i][d] = 255
				image[i][31][d] = 255
				image[31][i][d] = 255
			scipy.misc.toimage(image, cmin=0.0, cmax=255).save(filename)
		if filename.startswith("ship"):
			for i in range(0,32):
				image[i][0][b] = 255
				image[0][i][b] = 255
				image[i][31][b] = 255
				image[31][i][b] = 255
			scipy.misc.toimage(image, cmin=0.0, cmax=255).save(filename)
		if filename.startswith("auto"):
			for i in range(0,32):
				image[i][0][a] = 255
				image[0][i][a] = 255
				image[i][31][a] = 255
				image[31][i][a] = 255
			scipy.misc.toimage(image, cmin=0.0, cmax=255).save(filename)
